<nav id="context-menu" class="context-menu">
    <ul class="context-menu__items">
      <li class="context-menu__item">
        <a href="#" class="context-menu__link" data-action="View"><i class="fa fa-eye"></i> View</a>
      </li>
      <li class="context-menu__item">
        <a href="#" class="context-menu__link" data-action="Download"><i class="fa fa-download"></i> Download</a>
      </li>
       <li class="context-menu__item">
        <a href="#" class="context-menu__link" data-action="Rename"><i class="fa fa-edit"></i> Renombrar</a>
      </li>
      <li class="context-menu__item">
        <a href="#" class="context-menu__link" data-action="Delete"><i class="fa fa-times"></i> Delete</a>
      </li>
    </ul>
  </nav>