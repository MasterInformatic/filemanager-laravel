<div class="main" id="mainHeaderFixed">
    <div class="elements">

        <button class="btnTestOsmara btnMain" id="btnMain">
            <i class="fa fa-bars"></i>
        </button>

        <button class="btnTestOsmara ">
            <i class="fa fa-upload"></i>
            <span>Añadir</span>
        </button>

        <button class="btnTestOsmara " >
            <i class="fa fa-eye"></i>
            <span>Ver</span>
        </button>

        <button class="btnTestOsmara ">
            <i class="fa fa-file-download"></i>
            <span>Descargar</span>
        </button>

        <button class="btnTestOsmara ">
            <i class="fa fa-copy"></i>
            <span>Copiar</span>
        </button>

        <button class="btnTestOsmara ">
            <i class="fa fa-file-export"></i>
            <span>Mover</span>
        </button>

        <button class="btnTestOsmara ">
            <i class="fa fa-edit"></i>
            <span>Renombrar</span>
        </button>

        <button class="btnTestOsmara ">
            <i class="fa fa-trash"></i>
            <span>Eliminar</span>
        </button>

    </div>
</div>



