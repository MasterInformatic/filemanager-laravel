<div class="modalRename" id="modalRename">
	<div >
		
		<div class="close">
			<button class="btnclosemodal" id="btnCloseModal">
				x
			</button>
		</div>

		<div class="form">
			<div class="header">
				<span>
					Renombrar
				</span>
			</div>
			<div class="body">
				<div>
					<p>
						Introduzca el nuevo nombre
					</p>
				</div>
				<form action="">
					<input type="text" name="name">
				</form>
			</div>
			<div class="footer">
				<button id="btnSave">Guardar</button>
				<button id="btnCancel">Cancelar</button>
			</div>
		</div>

	</div>
</div>