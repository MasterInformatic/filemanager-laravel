<?php

return [


    'dir' => public_path()."/",


];
